"""
obstacle.py
-----------
This file contains the Obstacle class.
It handles:
    - Generating a list of wall obstacle blocks at random positions
    - Making sure obstacles do not spawn on the snake's starting position
    - Drawing the obstacles on the screen
"""

import random
import pygame
import settings


class Obstacle:
    def __init__(self, snake_start_body):
        self.positions = []   # List of (x, y) grid positions that are walls
        self._generate_obstacles(snake_start_body)

    def _generate_obstacles(self, snake_start_body):
        """
        Randomly places wall blocks on the grid.
        Obstacles will never spawn on the snake's starting body
        or too close to the edges where the snake first appears.
        """
        safe_zone = set(snake_start_body)

        # Also avoid placing obstacles right on the border cells,
        # so the play area does not feel too cramped.
        attempts = 0
        while len(self.positions) < settings.NUMBER_OF_OBSTACLES and attempts < 1000:
            attempts += 1
            x = random.randint(1, settings.GRID_WIDTH - 2)
            y = random.randint(1, settings.GRID_HEIGHT - 2)
            position = (x, y)

            if position in safe_zone:
                continue
            if position in self.positions:
                continue

            self.positions.append(position)

    def draw(self, screen):
        """Draws each obstacle block as a rounded grey rectangle."""
        for x, y in self.positions:
            rect = pygame.Rect(
                x * settings.CELL_SIZE,
                y * settings.CELL_SIZE,
                settings.CELL_SIZE,
                settings.CELL_SIZE,
            )
            inner_rect = rect.inflate(-2, -2)

            pygame.draw.rect(screen, settings.OBSTACLE_COLOR, inner_rect, border_radius=4)
            pygame.draw.rect(
                screen,
                settings.OBSTACLE_OUTLINE_COLOR,
                inner_rect,
                width=2,
                border_radius=4,
            )
