"""
snake.py
--------
This file contains the Snake class.
It handles:
    - Snake's starting position and body
    - Moving the snake
    - Growing the snake after eating food
    - Checking for collisions (with itself, walls, obstacles)
    - Drawing the snake on the screen with rounded rectangles
"""

import pygame
import settings


class Snake:
    def __init__(self):
        # The snake starts at the center of the grid.
        start_x = settings.GRID_WIDTH // 2
        start_y = settings.GRID_HEIGHT // 2

        # The snake's body is stored as a list of (x, y) grid positions.
        # The first element (index 0) is always the HEAD of the snake.
        self.body = [
            (start_x, start_y),
            (start_x - 1, start_y),
            (start_x - 2, start_y),
        ]

        # The snake starts moving to the right.
        self.direction = (1, 0)

        # This flag tells us if the snake just ate food (used to grow the body).
        self.grow_pending = False

    def change_direction(self, new_direction):
        """
        Changes the snake's direction, but prevents the snake
        from reversing directly into itself (e.g. moving right
        then instantly pressing left).
        """
        opposite_direction = (-self.direction[0], -self.direction[1])
        if new_direction != opposite_direction:
            self.direction = new_direction

    def move(self):
        """
        Moves the snake one step in the current direction.
        If grow_pending is True, the snake keeps its tail (grows by one cell).
        Otherwise, the tail is removed so the snake stays the same length.
        """
        head_x, head_y = self.body[0]
        dir_x, dir_y = self.direction
        new_head = (head_x + dir_x, head_y + dir_y)

        # Add the new head to the front of the body list.
        self.body.insert(0, new_head)

        if self.grow_pending:
            # Skip removing the tail this one time -> snake grows by 1 cell.
            self.grow_pending = False
        else:
            # Remove the last segment (tail) to keep the same length.
            self.body.pop()

    def grow(self):
        """Marks that the snake should grow on its next move."""
        self.grow_pending = True

    def get_head_position(self):
        """Returns the current position of the snake's head."""
        return self.body[0]

    def check_self_collision(self):
        """Returns True if the snake's head collides with its own body."""
        head = self.body[0]
        return head in self.body[1:]

    def check_wall_collision(self):
        """Returns True if the snake's head goes outside the playing grid."""
        head_x, head_y = self.body[0]
        if head_x < 0 or head_x >= settings.GRID_WIDTH:
            return True
        if head_y < 0 or head_y >= settings.GRID_HEIGHT:
            return True
        return False

    def check_obstacle_collision(self, obstacle_positions):
        """Returns True if the snake's head hits any obstacle block."""
        return self.body[0] in obstacle_positions

    def draw(self, screen):
        """
        Draws the snake on the screen.
        The head is drawn in a brighter color than the body,
        and every segment is drawn as a rounded rectangle for a
        smoother, more modern look.
        """
        for index, segment in enumerate(self.body):
            x, y = segment
            rect = pygame.Rect(
                x * settings.CELL_SIZE,
                y * settings.CELL_SIZE,
                settings.CELL_SIZE,
                settings.CELL_SIZE,
            )

            # Slightly shrink the rectangle to create a small gap between
            # segments, which gives a clean "blocky but smooth" snake look.
            inner_rect = rect.inflate(-4, -4)

            if index == 0:
                color = settings.SNAKE_HEAD_COLOR
            else:
                color = settings.SNAKE_BODY_COLOR

            pygame.draw.rect(screen, color, inner_rect, border_radius=8)

        # Draw simple "eyes" on the head to make the snake feel alive.
        self._draw_eyes(screen)

    def _draw_eyes(self, screen):
        """Draws two small eyes on the snake's head based on its direction."""
        head_x, head_y = self.body[0]
        center_x = head_x * settings.CELL_SIZE + settings.CELL_SIZE // 2
        center_y = head_y * settings.CELL_SIZE + settings.CELL_SIZE // 2

        eye_radius = 3
        offset = 6  # distance of each eye from the center of the head

        dir_x, dir_y = self.direction

        if dir_x == 1:    # moving right
            eye1 = (center_x + 4, center_y - offset)
            eye2 = (center_x + 4, center_y + offset)
        elif dir_x == -1:  # moving left
            eye1 = (center_x - 4, center_y - offset)
            eye2 = (center_x - 4, center_y + offset)
        elif dir_y == 1:   # moving down
            eye1 = (center_x - offset, center_y + 4)
            eye2 = (center_x + offset, center_y + 4)
        else:              # moving up
            eye1 = (center_x - offset, center_y - 4)
            eye2 = (center_x + offset, center_y - 4)

        pygame.draw.circle(screen, settings.DARK_BACKGROUND, eye1, eye_radius)
        pygame.draw.circle(screen, settings.DARK_BACKGROUND, eye2, eye_radius)
