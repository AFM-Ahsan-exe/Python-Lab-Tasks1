"""
food.py
-------
This file contains the Food class.
It handles:
    - Spawning fruit at random positions on the grid
    - Making sure fruit never spawns inside the snake's body or obstacles
    - Spawning a special golden fruit (after score > 150) that gives double points
    - Drawing the fruit on the screen
"""

import random
import pygame
import settings


class Food:
    def __init__(self):
        self.position = (0, 0)
        self.is_golden = False     # True if this fruit is the special golden fruit
        self.points = settings.NORMAL_FOOD_POINTS

    def spawn(self, snake_body, obstacle_positions, current_score):
        """
        Picks a new random position for the fruit.
        The position must NOT be on top of the snake or any obstacle.

        After the score passes GOLDEN_FOOD_SCORE_THRESHOLD, there is a
        chance the fruit spawns as a golden fruit worth double points.
        """
        # Build a list of all grid cells that are blocked (snake + obstacles).
        blocked_cells = set(snake_body) | set(obstacle_positions)

        # Build a list of all free cells on the grid.
        free_cells = []
        for x in range(settings.GRID_WIDTH):
            for y in range(settings.GRID_HEIGHT):
                if (x, y) not in blocked_cells:
                    free_cells.append((x, y))

        # Pick a random free cell for the new fruit.
        # (If, in an extreme edge case, there are no free cells, the snake
        # has filled the whole board, so we just keep the old position.)
        if free_cells:
            self.position = random.choice(free_cells)

        # Decide whether this fruit should be a golden (bonus) fruit.
        if current_score > settings.GOLDEN_FOOD_SCORE_THRESHOLD:
            if random.random() < settings.GOLDEN_FOOD_SPAWN_CHANCE:
                self.is_golden = True
                self.points = settings.GOLDEN_FOOD_POINTS
                return

        # Otherwise, spawn a normal fruit.
        self.is_golden = False
        self.points = settings.NORMAL_FOOD_POINTS

    def draw(self, screen, pulse_value):
        """
        Draws the fruit as a smooth circle.
        'pulse_value' is a small number (changing over time) used to make
        the fruit gently grow/shrink, giving a simple pulsing animation.
        """
        x, y = self.position
        center_x = x * settings.CELL_SIZE + settings.CELL_SIZE // 2
        center_y = y * settings.CELL_SIZE + settings.CELL_SIZE // 2

        base_radius = settings.CELL_SIZE // 2 - 3
        radius = base_radius + pulse_value

        color = settings.GOLDEN_FOOD_COLOR if self.is_golden else settings.FOOD_COLOR

        pygame.draw.circle(screen, color, (center_x, center_y), radius)

        # Draw a small highlight circle to give the fruit a subtle shine.
        highlight_radius = max(radius // 3, 2)
        highlight_pos = (center_x - radius // 3, center_y - radius // 3)
        highlight_color = (255, 255, 255)
        pygame.draw.circle(screen, highlight_color, highlight_pos, highlight_radius)
