# Snake Game (Python + Pygame)

A modular, beginner-friendly Snake Game built with **Python** and **Pygame**, created for the AI Lab assignment.

The game features a modern dark-themed UI, growing snake mechanics, score tracking with persistent high score, wall obstacles, a special golden bonus fruit, and a Game Over screen with Restart/Quit options.

---

## 📁 Project Structure

```
SnakeGame/
├── main.py            # Entry point - game loop, input handling, game over screen
├── settings.py         # All constants: colors, sizes, speed, scoring rules
├── snake.py            # Snake class - movement, growth, collision checks, drawing
├── food.py             # Food class - spawning logic (normal + golden fruit), drawing
├── obstacle.py         # Obstacle class - wall block generation and drawing
├── score.py            # Score class - score tracking, high score file save/load
├── requirements.txt    # Python dependencies
└── README.md           # This file
```

---

## ✨ Features

- 🎮 **Arrow key controls** (Up / Down / Left / Right)
- 🐍 **Snake grows** by one segment every time it eats a fruit
- 🔴 **Normal fruit** gives **10 points**
- 🟡 **Golden fruit** appears only after your score passes **150**, and gives **double points (20)**
- ⚡ **Speed doubles** automatically once your score exceeds **100**
- 🧱 **Wall obstacles** scattered on the map — touching one ends the game
- 🚫 Fruit **never spawns inside the snake's body or inside an obstacle**
- 🏆 **Score** and **High Score** displayed live during gameplay (high score is saved to `high_score.txt` and persists between runs)
- 💀 **Game Over screen** with **Restart** and **Quit** buttons (mouse-clickable, or press `R` to restart / `Q`/`Esc` to quit)
- 🎨 Clean modern UI: dark background, subtle grid lines, rounded snake/food shapes, simple pulsing fruit animation, and snake "eyes" that face the direction of movement

---

## 🛠 Requirements

- Python 3.13 (also works on Python 3.8+)
- Pygame library

---

## 📦 Installation

1. **Download / extract the project folder** (`SnakeGame/`).

2. **(Optional but recommended)** create a virtual environment:
   ```bash
   python -m venv venv
   ```
   Activate it:
   - Windows: `venv\Scripts\activate`
   - macOS/Linux: `source venv/bin/activate`

3. **Install the dependencies:**
   ```bash
   pip install -r requirements.txt
   ```
   or simply:
   ```bash
   pip install pygame
   ```

---

## ▶️ How to Run

From inside the `SnakeGame/` folder, run:

```bash
python main.py
```

(On some systems you may need to use `python3 main.py` instead.)

---

## 🎯 Controls

| Key          | Action              |
|--------------|---------------------|
| ↑ Up Arrow   | Move Up             |
| ↓ Down Arrow | Move Down           |
| ← Left Arrow | Move Left           |
| → Right Arrow| Move Right          |
| R            | Restart (after Game Over) |
| Q / Esc      | Quit (after Game Over)    |

You can also click the **Restart** or **Quit** buttons with the mouse on the Game Over screen.

---

## 📝 How the Game Works (Quick Explanation for Viva)

1. **main.py** runs the game loop: it reads keyboard input, tells the snake to move, checks for collisions, and draws everything to the screen every frame.
2. **snake.py** stores the snake's body as a list of grid coordinates. Moving the snake means adding a new head position and removing the tail — unless the snake just ate food, in which case the tail is kept so the snake grows by one cell.
3. **food.py** picks a random empty grid cell (one not occupied by the snake or an obstacle) for the fruit to appear. Once the score passes 150, there's a chance the fruit spawns "golden" instead, which is worth double the normal points.
4. **obstacle.py** randomly places a fixed number of wall blocks on the grid when the game starts. If the snake's head touches one, the game ends.
5. **score.py** keeps track of the current score and the all-time high score, saving the high score to `high_score.txt` so it's remembered the next time you play.
6. When the snake hits a wall, an obstacle, or itself, **main.py** shows the **Game Over screen**, where you can restart or quit.

---

## 🙋 Notes

- The high score is stored locally in a file called `high_score.txt`, automatically created in the same folder the first time you play.
- The code intentionally avoids advanced design patterns (no inheritance hierarchies, no complex OOP) so it stays easy to read, explain, and modify for lab/viva purposes.
