"""
main.py
-------
This is the entry point of the Snake Game.
It contains the main game loop and handles:
    - Initializing pygame and the game window
    - Handling keyboard input (arrow keys)
    - Updating the snake, food, and obstacles every frame
    - Checking for collisions and ending the game
    - Drawing the grid background and all game objects
    - Showing the Game Over screen with Restart and Quit buttons
"""

import sys
import math
import pygame

import settings
from snake import Snake
from food import Food
from obstacle import Obstacle
from score import Score


def draw_grid(screen):
    """
    Draws a subtle grid on the background.
    This gives the game a clean, modern look instead of a plain solid color.
    """
    for x in range(0, settings.SCREEN_WIDTH, settings.CELL_SIZE):
        pygame.draw.line(screen, settings.GRID_LINE_COLOR, (x, 0), (x, settings.SCREEN_HEIGHT))
    for y in range(0, settings.SCREEN_HEIGHT, settings.CELL_SIZE):
        pygame.draw.line(screen, settings.GRID_LINE_COLOR, (0, y), (settings.SCREEN_WIDTH, y))


def draw_button(screen, rect, text, font, is_hovered):
    """
    Draws a single rounded rectangle button with centered text.
    'is_hovered' changes the button's color slightly for a simple
    interactive feel when the mouse is over it.
    """
    color = settings.BUTTON_HOVER_COLOR if is_hovered else settings.BUTTON_COLOR
    pygame.draw.rect(screen, color, rect, border_radius=12)
    pygame.draw.rect(screen, settings.HIGHLIGHT_COLOR, rect, width=2, border_radius=12)

    text_surface = font.render(text, True, settings.TEXT_COLOR)
    text_rect = text_surface.get_rect(center=rect.center)
    screen.blit(text_surface, text_rect)


def show_game_over_screen(screen, score_obj):
    """
    Displays the Game Over screen with the final score, high score,
    and two buttons: Restart and Quit.

    Returns:
        "restart" if the player clicks Restart,
        "quit" if the player clicks Quit or closes the window.
    """
    title_font = pygame.font.SysFont(settings.FONT_NAME, 56, bold=True)
    info_font = pygame.font.SysFont(settings.FONT_NAME, 26)
    button_font = pygame.font.SysFont(settings.FONT_NAME, 24, bold=True)

    # Define button rectangles (centered on screen).
    button_width, button_height = 160, 50
    center_x = settings.SCREEN_WIDTH // 2

    restart_rect = pygame.Rect(
        center_x - button_width - 15,
        settings.SCREEN_HEIGHT // 2 + 50,
        button_width,
        button_height,
    )
    quit_rect = pygame.Rect(
        center_x + 15,
        settings.SCREEN_HEIGHT // 2 + 50,
        button_width,
        button_height,
    )

    while True:
        mouse_pos = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return "quit"

            if event.type == pygame.MOUSEBUTTONDOWN:
                if restart_rect.collidepoint(mouse_pos):
                    return "restart"
                if quit_rect.collidepoint(mouse_pos):
                    return "quit"

            if event.type == pygame.KEYDOWN:
                # Allow keyboard shortcuts too: R to restart, Q/ESC to quit.
                if event.key == pygame.K_r:
                    return "restart"
                if event.key in (pygame.K_q, pygame.K_ESCAPE):
                    return "quit"

        # ---- Draw the Game Over screen ----
        screen.fill(settings.DARK_BACKGROUND)
        draw_grid(screen)

        # Semi-transparent dark overlay to focus attention on the text/buttons.
        overlay = pygame.Surface((settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT))
        overlay.set_alpha(180)
        overlay.fill(settings.DARK_BACKGROUND)
        screen.blit(overlay, (0, 0))

        # "Game Over" title text.
        title_text = title_font.render("GAME OVER", True, settings.GAME_OVER_COLOR)
        title_rect = title_text.get_rect(center=(center_x, settings.SCREEN_HEIGHT // 2 - 80))
        screen.blit(title_text, title_rect)

        # Final score and high score text.
        score_text = info_font.render(
            f"Final Score: {score_obj.current_score}   |   High Score: {score_obj.high_score}",
            True,
            settings.TEXT_COLOR,
        )
        score_rect = score_text.get_rect(center=(center_x, settings.SCREEN_HEIGHT // 2 - 20))
        screen.blit(score_text, score_rect)

        # Draw the Restart and Quit buttons (with hover highlight).
        draw_button(screen, restart_rect, "Restart", button_font, restart_rect.collidepoint(mouse_pos))
        draw_button(screen, quit_rect, "Quit", button_font, quit_rect.collidepoint(mouse_pos))

        pygame.display.flip()


def run_game(screen, clock):
    """
    Runs a single playthrough of the game, from start until the
    snake collides with something (wall, obstacle, or itself).

    Returns the Score object so main() can show the final results.
    """
    snake = Snake()
    obstacles = Obstacle(snake.body)
    food = Food()
    food.spawn(snake.body, obstacles.positions, 0)

    score_obj = Score()

    current_speed = settings.INITIAL_SPEED
    speed_boost_applied = False

    # 'frame_count' is used to create a simple pulsing animation for the fruit.
    frame_count = 0

    running = True
    while running:
        # ---- 1. Handle Events (keyboard input) ----
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    snake.change_direction((0, -1))
                elif event.key == pygame.K_DOWN:
                    snake.change_direction((0, 1))
                elif event.key == pygame.K_LEFT:
                    snake.change_direction((-1, 0))
                elif event.key == pygame.K_RIGHT:
                    snake.change_direction((1, 0))

        # ---- 2. Update Game State ----
        snake.move()

        # Check if the snake ate the fruit.
        if snake.get_head_position() == food.position:
            score_obj.add_points(food.points)
            snake.grow()
            food.spawn(snake.body, obstacles.positions, score_obj.current_score)

        # Speed doubles permanently once the score passes the threshold.
        if score_obj.current_score > settings.SPEED_BOOST_SCORE and not speed_boost_applied:
            current_speed = settings.FAST_SPEED
            speed_boost_applied = True

        # ---- 3. Check for Collisions (Game Over conditions) ----
        if snake.check_wall_collision():
            running = False
        elif snake.check_self_collision():
            running = False
        elif snake.check_obstacle_collision(obstacles.positions):
            running = False

        # ---- 4. Draw Everything ----
        screen.fill(settings.DARK_BACKGROUND)
        draw_grid(screen)

        obstacles.draw(screen)

        # Simple pulsing animation for the fruit using a sine wave.
        pulse_value = int(2 * math.sin(frame_count * 0.2))
        food.draw(screen, pulse_value)

        snake.draw(screen)
        score_obj.draw(screen)

        pygame.display.flip()

        frame_count += 1
        clock.tick(current_speed)

    # Save the high score to file before returning, so progress is not lost.
    score_obj.save_high_score()
    return score_obj


def main():
    """Initializes pygame and runs the main program loop (play -> game over -> restart)."""
    pygame.init()
    screen = pygame.display.set_mode((settings.SCREEN_WIDTH, settings.SCREEN_HEIGHT))
    pygame.display.set_caption(settings.GAME_TITLE)
    clock = pygame.time.Clock()

    while True:
        score_obj = run_game(screen, clock)
        choice = show_game_over_screen(screen, score_obj)

        if choice == "quit":
            pygame.quit()
            sys.exit()
        # If choice == "restart", the while loop simply calls run_game() again.


if __name__ == "__main__":
    main()
