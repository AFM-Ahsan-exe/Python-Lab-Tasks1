"""
score.py
--------
This file contains the Score class.
It handles:
    - Keeping track of the current score
    - Loading and saving the high score to a text file
    - Drawing the score and high score on the screen
"""

import os
import pygame
import settings


class Score:
    def __init__(self):
        self.current_score = 0
        self.high_score = self._load_high_score()

    def _load_high_score(self):
        """
        Loads the high score from a text file.
        If the file does not exist yet (first time playing),
        the high score simply starts at 0.
        """
        if os.path.exists(settings.HIGH_SCORE_FILE):
            try:
                with open(settings.HIGH_SCORE_FILE, "r") as file:
                    content = file.read().strip()
                    return int(content) if content else 0
            except (ValueError, IOError):
                return 0
        return 0

    def save_high_score(self):
        """Saves the current high score to the text file."""
        try:
            with open(settings.HIGH_SCORE_FILE, "w") as file:
                file.write(str(self.high_score))
        except IOError:
            # If the file cannot be written (e.g. permission issue),
            # we simply skip saving instead of crashing the game.
            pass

    def add_points(self, points):
        """Adds points to the current score and updates the high score if needed."""
        self.current_score += points
        if self.current_score > self.high_score:
            self.high_score = self.current_score

    def reset(self):
        """Resets the current score back to 0 (used when restarting the game)."""
        self.current_score = 0

    def draw(self, screen):
        """
        Draws the current score and high score in the top corners
        of the screen, each inside a small rounded background panel.
        """
        font = pygame.font.SysFont(settings.FONT_NAME, 24, bold=True)

        # ---- Current Score (top-left) ----
        score_text = font.render(f"Score: {self.current_score}", True, settings.TEXT_COLOR)
        score_panel = pygame.Rect(10, 10, score_text.get_width() + 20, 36)
        pygame.draw.rect(screen, settings.SCORE_BG_COLOR, score_panel, border_radius=10)
        screen.blit(score_text, (score_panel.x + 10, score_panel.y + 6))

        # ---- High Score (top-right) ----
        high_score_text = font.render(f"High Score: {self.high_score}", True, settings.HIGHLIGHT_COLOR)
        high_score_panel = pygame.Rect(
            settings.SCREEN_WIDTH - high_score_text.get_width() - 30,
            10,
            high_score_text.get_width() + 20,
            36,
        )
        pygame.draw.rect(screen, settings.SCORE_BG_COLOR, high_score_panel, border_radius=10)
        screen.blit(high_score_text, (high_score_panel.x + 10, high_score_panel.y + 6))
