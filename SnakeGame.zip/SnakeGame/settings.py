"""
settings.py
-----------
This file stores all the constant values used in the game.
Keeping them in one place makes it easy to change the game's
look and feel without touching the game logic in other files.
"""

# ---------- SCREEN SETTINGS ----------
CELL_SIZE = 25          # Size of one grid cell in pixels (snake, food, obstacles all fit this grid)
GRID_WIDTH = 28         # Number of cells horizontally
GRID_HEIGHT = 20        # Number of cells vertically

SCREEN_WIDTH = CELL_SIZE * GRID_WIDTH     # 700 px
SCREEN_HEIGHT = CELL_SIZE * GRID_HEIGHT   # 500 px

GAME_TITLE = "Snake Game - AI Lab Project"

# ---------- COLORS (R, G, B) ----------
# A dark, modern color theme as requested in the requirements
DARK_BACKGROUND = (24, 26, 34)        # Main background color (dark navy/black)
GRID_LINE_COLOR = (34, 37, 48)        # Slightly lighter than background for subtle grid lines

SNAKE_HEAD_COLOR = (88, 222, 150)     # Bright green for the snake's head
SNAKE_BODY_COLOR = (58, 175, 120)     # Slightly darker green for the snake's body
SNAKE_OUTLINE_COLOR = (24, 26, 34)    # Outline color to separate snake segments

FOOD_COLOR = (235, 87, 87)            # Normal fruit color (red)
GOLDEN_FOOD_COLOR = (245, 199, 70)    # Yellow/golden fruit color (bonus fruit)

OBSTACLE_COLOR = (90, 95, 110)        # Wall obstacle color (cool grey)
OBSTACLE_OUTLINE_COLOR = (130, 135, 150)

TEXT_COLOR = (235, 235, 240)          # Main text color (off-white)
SCORE_BG_COLOR = (32, 35, 46)         # Background panel color behind the score text
HIGHLIGHT_COLOR = (88, 222, 150)      # Used for highlights/buttons (green)
GAME_OVER_COLOR = (235, 87, 87)       # Red text used for "Game Over"
BUTTON_COLOR = (45, 49, 64)           # Button background color
BUTTON_HOVER_COLOR = (60, 65, 84)     # Button background when hovered

# ---------- GAME SPEED SETTINGS ----------
INITIAL_SPEED = 10          # Initial snake speed (moves/updates per second)
FAST_SPEED = 20             # Speed after score crosses 100 (doubled speed)
SPEED_BOOST_SCORE = 100     # Score threshold after which speed doubles

# ---------- SCORING SETTINGS ----------
NORMAL_FOOD_POINTS = 10     # Points given for eating a normal (red) fruit
GOLDEN_FOOD_POINTS = 20     # Points given for eating a golden (yellow) fruit (double points)
GOLDEN_FOOD_SCORE_THRESHOLD = 150   # Golden fruit starts appearing after this score
GOLDEN_FOOD_SPAWN_CHANCE = 0.35     # Probability that a golden fruit spawns instead of a normal one

# ---------- OBSTACLE SETTINGS ----------
NUMBER_OF_OBSTACLES = 10    # Number of wall obstacle blocks placed on the map

# ---------- FILE PATHS ----------
HIGH_SCORE_FILE = "high_score.txt"   # File used to store the high score between game runs

# ---------- FONT SETTINGS ----------
FONT_NAME = "arial"
